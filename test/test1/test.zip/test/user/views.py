from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse


def index(request):
    return HttpResponse("안녕하세요 user에 오신것을 환영합니다.")