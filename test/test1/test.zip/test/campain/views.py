from django.shortcuts import render
from django.http import HttpResponse


def index(campain):
    return HttpResponse("안녕하세요 campain에 오신것을 환영합니다.")

def detail(campain, campain_id):
    """
    campain 내용 출력
    """
    campain = Campain.objects.get(id=campain_id)
    context = {'campain': campain}
    return render(campain, 'campain/campain_detail.html', context)