from django.apps import AppConfig


class CampainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'campain'
