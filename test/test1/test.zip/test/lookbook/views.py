from django.shortcuts import render
from django.http import HttpResponse


def index(lookbook):
    return HttpResponse("안녕하세요 lookbook에 오신것을 환영합니다.")