from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),

    path('campain/', include('campain.urls')),
    path('common/', include('common.urls')),
    path('company/', include('company.urls')),
    path('lookbook/', include('lookbook.urls')),
    path('shop/', include('shop.urls')),
    path('user/', include('user.urls')),
]
